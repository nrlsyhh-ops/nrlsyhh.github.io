public class FoodDonation 
{
    private String foodID;
    private String foodName;
    private int foodQty;
    private String foodExpDate;
    private String victimID;
    private String foodStatus;
    
    public FoodDonation(String a,String b,int c,String d,String e,String f)
    {
        this.foodID=a;
        this.foodName=b;
        this.foodQty=c;
        this.foodExpDate=d;
        this.victimID=e;
        this.foodStatus=f;
    }
    
    public String getFoodID(){return this.foodID;}
    public String getFoodName(){return this.foodName;}//ni aku tambah pun tapi dalam proposal x de
    public int getFoodQty(){return this.foodQty;}
    public String getFoodExpDate(){return this.foodExpDate;}
    public String getVictimID(){return this.victimID;}
    public String getStatus(){return this.foodStatus;}
    
    public void setFoodID(String a){this.foodID=a;}
    public void setFoodQty(int a){ this.foodQty=a;}
    public void setFoodExpDate(String a){this.foodExpDate=a;}
    public void setVictimID(String a){this.victimID=a;}
    public void setStatus(String a){this.foodStatus=a;}
    
    public String toString(){return String.format("\nFood ID : %s \nFood Name : %s \nQuantity : %d \nExpiry Date : %s \nVictim ID : %s \nStatus : %s ",foodID,foodName,foodQty,foodExpDate,victimID,foodStatus);}
}