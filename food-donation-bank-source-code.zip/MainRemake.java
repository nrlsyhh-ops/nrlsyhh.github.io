import java.io.File;
import java.util.Scanner;
import java.util.StringTokenizer;


public class MainRemake {
    public static void main(String[] args) {

        // ===== DECLARATIONS =====
        LinkedList<FoodDonation> fdLL = new LinkedList<>();
        Queue<Victim> qVic = new Queue(); 
        Scanner sc = new Scanner(System.in);
        LinkedList<FoodDonation> distribute = new LinkedList<>();
        // ===== LOAD VICTIM FILE =====
        try {
         File f = new File("Victim.txt");
            Scanner s = new Scanner(f);

            while (s.hasNextLine()) {
                String st = s.nextLine();
                StringTokenizer sr = new StringTokenizer(st, ";");

                String vID = sr.nextToken();
                String vName = sr.nextToken();
                String vPhoneNo = sr.nextToken();
                String vAddress = sr.nextToken();
                int vFamSize = Integer.parseInt(sr.nextToken());

                Victim v = new Victim(vID, vName, vPhoneNo, vAddress, vFamSize);
                qVic.enqueue(v);
            }
            s.close();
        } catch (Exception e) {
            System.out.println("Error reading Victim file");
        }

        // ===== LOAD FOOD DONATION FILE =====
        try {
            File f2 = new File("FoodDonation.txt");
            Scanner s2 = new Scanner(f2);

            while (s2.hasNextLine()) {
                String line = s2.nextLine();
                StringTokenizer st = new StringTokenizer(line, ";");

                String fID = st.nextToken();
                String fName = st.nextToken();
                int qty = Integer.parseInt(st.nextToken());
                String exp = st.nextToken();
                String vID = st.nextToken();
                String fStat = st.nextToken();

                FoodDonation fd = new FoodDonation(fID, fName, qty, exp, vID, fStat);
                fdLL.addLast(fd);
            }
            s2.close();
        } catch (Exception e) {
            System.out.println("Error reading Food Donation file");
        }

        // ===== MENU =====
        int choice;
        do {
            choice = displayMessage(sc);

            switch (choice) {
                case 1:
                    //displayFoodDonations;
                    displayFoodDonations(fdLL);
                    break;

                case 2:
                    //displayVictimQueue;
                    displayVictim(qVic);
                    break;

                case 3:
                    //searchFoodDonation;
                    searchFoodDonation(fdLL);
                    break;

                case 4:
                    //updateFoodStatus;
                    updateFoodDonation(fdLL);
                    break;

                case 5:
                    //distributeFood;
                    distribute = distributeFood(fdLL);
                    System.out.println("\n=============================== DISTRIBUTED FOOD LIST ===================================");
                    displayFoodDonations(distribute);
                    System.out.println("\n=========================================================================================");
                    
                    break;

                case 6:
                    //removeDistributedFood;
                    fdLL = removeDistributed(fdLL);
                    System.out.println("\n====================================== UPDATED FOOD LIST =======================================");
                    displayFoodDonations(fdLL);
                    System.out.println("\n=================================================================================================");
                    
                    break;
                case 7:
                    insertNewFood(fdLL);
                    
                    FoodDonation f = fdLL.getFirst();
                    System.out.println("\n====================================== UPDATED FOOD LIST =======================================");
                    while (f != null) 
                    {
                        System.out.printf("%-10s | %-32s | %5d | %-15s | %-12s | %-12s%n",
                        f.getFoodID(), f.getFoodName(), f.getFoodQty(),
                        f.getFoodExpDate(), f.getVictimID(), f.getStatus());
                        f = fdLL.getNext();
                    }
                    System.out.println("\n=================================================================================================");
                    break;
                case 8 : 
                    //add distributed food
                    distributingOperation(fdLL,qVic);
                case 0:
                    System.out.println("Thank you. Program ended.");
                    break;

                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 0);
        
    }
    
    private static int displayMessage(Scanner in)
    {
        int choise ;
        
        System.out.println("\n============= FOOD DONATION SYSTEM ==============");
            System.out.println("1. Display Food Donations");
            System.out.println("2. Display Victim Queue");
            System.out.println("3. Search Food Donation");
            System.out.println("4. Update Food Donation");
            System.out.println("5. Distribute Food");
            System.out.println("6. Remove Distributed Food");
            System.out.println("7. Add New Food");
            System.out.println("0. Exit");
            System.out.println("==================================================\n");
            System.out.print("Enter choice: ");
            choise = in.nextInt();
            in.nextLine();
            
            return choise;
    }
    
    private static void displayFoodDonations(LinkedList<FoodDonation> fdLL) 
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("\nWould you like to filter display by:");
        System.out.println("1. Status");
        System.out.println("2. Victim ID");
        System.out.println("3. No filter");
        System.out.print("Enter choice: ");
        int choice = sc.nextInt();
        sc.nextLine();
        FoodDonation f = fdLL.getFirst();
        boolean found = false;
        System.out.printf("%-10s | %-32s | %5s | %-15s | %-12s | %-12s%n",
        "FOOD ID", "FOOD NAME", "QTY", "EXPIRY DATE", "VICTIM ID", "STATUS");
        System.out.println("-----------------------------------------------------------------------------------------------");
        if (choice == 1) 
        {
            System.out.print("Enter Status (Pending / Approved / Distributed): ");
            String status = sc.nextLine();
            while (f != null) 
            {
                if (f.getStatus().equalsIgnoreCase(status)) 
                {
                    System.out.printf("%-10s | %-32s | %5d | %-15s | %-12s | %-12s%n",
                    f.getFoodID(), f.getFoodName(), f.getFoodQty(),
                    f.getFoodExpDate(), f.getVictimID(), f.getStatus());
                    found = true;
                }
                f = fdLL.getNext();
            }
            if (!found)
                System.out.println("No food donation found with this status.");
            }
        else if (choice == 2) 
        {
            System.out.print("Enter Victim ID: ");
            String victimID = sc.nextLine();
            while (f != null) 
            {
                if (f.getVictimID().equalsIgnoreCase(victimID)) 
                {
                    System.out.printf("%-10s | %-32s | %5d | %-15s | %-12s | %-12s%n",
                    f.getFoodID(), f.getFoodName(), f.getFoodQty(),
                    f.getFoodExpDate(), f.getVictimID(), f.getStatus());
                    found = true;
                }
                f = fdLL.getNext();
            }
            if (!found)
            System.out.println("No food donation found for this victim ID.");
        }
        else if (choice == 3) 
        {
        while (f != null) 
        {
            System.out.printf("%-10s | %-32s | %5d | %-15s | %-12s | %-12s%n",
            f.getFoodID(), f.getFoodName(), f.getFoodQty(),
            f.getFoodExpDate(), f.getVictimID(), f.getStatus());
            f = fdLL.getNext();
        }
        }
        else {
        System.out.println("Invalid choice. Returning to main menu.");
        }
    }

    
        private static void displayVictim(Queue<Victim> vq)
    {
        Queue<Victim> temp = new Queue();
    
        System.out.printf("\n%-10s | %-28s | %-11s | %-15s | %-5s%n","VICTIM ID", "NAME", "PHONE", "ADDRESS", "FAMILY SIZE");
        System.out.println("------------------------------------------------------------------------------------------");
    
        while (!vq.isEmpty())
        {
            Victim v = vq.dequeue();
            temp.enqueue(v);
    
            System.out.printf("%-10s | %-28s | %-11s | %-15s | %-5d%n",v.getVictimID(), v.getName(),v.getPhone(),v.getAddress(),v.getFamSize());
        }
        
        while(!temp.isEmpty())
        {
            Victim v = temp.dequeue();
            vq.enqueue(v);
        }
    }

    
    private static void searchFoodDonation(LinkedList<FoodDonation> fdLL)
    {
        Scanner in = new Scanner(System.in);
        String search;
        boolean state = false;
        
        System.out.println("Enter Food ID:");
        search = in.nextLine();
        
        
        FoodDonation f = fdLL.getFirst();
        while(f !=null)
        {
            if(f.getFoodID().equals(search))
            {
                state = true;
                break;
            }
            f = fdLL.getNext();
        }
        
        if(state == true)
        {
            System.out.printf("\n%-10s | %-30s | %5s | %-15s | %-12s | %-12s%n","FOOD ID", "FOOD NAME", "QTY", "EXPIRY DATE", "VICTIM ID", "STATUS");
            System.out.println("-----------------------------------------------------------------------------------------------");
            
            System.out.printf("\n%-10s | %-30s | %5d | %-15s | %-12s | %-12s%n",f.getFoodID(),f.getFoodName(),f.getFoodQty(),f.getFoodExpDate(),f.getVictimID(),f.getStatus());

        }
        else
        {
            System.out.println("Food ID Not Found.");
        }
    }
    
    private static void updateFoodDonation(LinkedList<FoodDonation> fdLL)
    {
        Scanner in = new Scanner(System.in);
        String search;
        char s,a;
        boolean state = false;
        String set ;
        
        FoodDonation fm = fdLL.getFirst();
         System.out.printf("%-10s | %-32s | %5s | %-15s | %-12s | %-12s%n",
        "FOOD ID", "FOOD NAME", "QTY", "EXPIRY DATE", "VICTIM ID", "STATUS");
        System.out.println("-----------------------------------------------------------------------------------------------");
        while (fm != null) 
        {
            System.out.printf("%-10s | %-32s | %5d | %-15s | %-12s | %-12s%n",
            fm.getFoodID(), fm.getFoodName(), fm.getFoodQty(),
            fm.getFoodExpDate(), fm.getVictimID(), fm.getStatus());
            fm = fdLL.getNext();
        }
        System.out.println("-----------------------------------------------------------------------------------------------");
        
        System.out.println("\nWould you like to update the food donation list? ( Y-yes || N-no || X-Exit)");
        s = in.nextLine().charAt(0);
        while(s=='Y'|| s == 'y')
        {
                System.out.println("Enter the food ID you would like to update:");
                search = in.nextLine();             
                FoodDonation f = fdLL.getFirst();
                while(f !=null)
                {
                    if(f.getFoodID().equalsIgnoreCase(search))
                    {
                        System.out.println("\n======================================== CURRENT FOOD INFO ========================================");
                        System.out.printf("%-10s | %-30s | %5s | %-15s | %-12s | %-12s%n","FOOD ID", "FOOD NAME", "QTY", "EXPIRY DATE", "VICTIM ID", "STATUS");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.printf("%-10s | %-30s | %5d | %-15s | %-12s | %-12s%n",f.getFoodID(),f.getFoodName(),f.getFoodQty(),f.getFoodExpDate(),f.getVictimID(),f.getStatus());
                        
                        System.out.println("\nWould you like to (1. Update Status || 2, Update Victim ID):");
                        a = in.nextLine().charAt(0);
                        
                        switch(a)
                        {
                            case '1' : System.out.println("\nEnter New Food Status:");
                                        set=in.nextLine();
                                        f.setStatus(set);
                                        state = true;
                                        break;
                                
                            case '2' : System.out.println("\nEnter New Victim ID:");
                                        set=in.nextLine();
                                        
                                        f.setVictimID(set);
                                        state = true;
                                        break;
                                        
                            default : System.out.println("\nEnter Valid Number!");
                            
                        }
                    }
                    else
                    {
                        state = false;
                    }
                    f = fdLL.getNext();
                }
                
                if(state == true)
                {
                    FoodDonation fk = fdLL.getFirst();
                    System.out.println("\nFood Updated!New Food Info:\n");
                    System.out.println("\n\n======================================== CURRENT FOOD INFO ========================================");
                    System.out.printf("%-10s | %-30s | %5s | %-15s | %-12s | %-12s%n","FOOD ID", "FOOD NAME", "QTY", "EXPIRY DATE", "VICTIM ID", "STATUS");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.printf("%-10s | %-30s | %5d | %-15s | %-12s | %-12s%n",fk.getFoodID(),fk.getFoodName(),fk.getFoodQty(),fk.getFoodExpDate(),fk.getVictimID(),fk.getStatus());
                }
                else
                {
                    System.out.println("Food ID Not Found.");
                }
                System.out.println("\nWould you like to update the food donation list again? ( Y-yes || N-no || X-Exit)");
                s = in.nextLine().charAt(0);
            }
    }
    
    private static LinkedList distributeFood(LinkedList<FoodDonation> fdLL)
    {
        FoodDonation f = fdLL.getFirst();
        LinkedList<FoodDonation> dist = new LinkedList();
        
        while(f !=null)
        {
            if(f.getStatus().equalsIgnoreCase("Distributed"))
            {
                dist.addLast(f);
            }
            
            f = fdLL.getNext();
        }
        
        return dist;
    }
    
    private static LinkedList removeDistributed(LinkedList<FoodDonation> fdLL)
    {
        
        
        FoodDonation f = fdLL.removeFirst();
        
        LinkedList<FoodDonation> temp = new LinkedList();
        System.out.println("======================================== DELETING FOOD ========================================");
        System.out.printf("%-7s | %-32s | %-3s | %-11s | %-10s | %-12s%n","FOOD ID", "FOOD NAME", "QTY", "EXPIRY DATE", "VICTIM ID", "STATUS");
        System.out.println("-----------------------------------------------------------------------------------------------");
        while(f != null)
        {
            if(f.getStatus().equalsIgnoreCase("Distributed"))
            {
                System.out.printf("%-7s | %-32s | %-3d | %-11s | %-10s | %-12s%n",f.getFoodID(),f.getFoodName(),f.getFoodQty(),f.getFoodExpDate(),f.getVictimID(),f.getStatus());
            }
            else
            {
                temp.addLast(f);
            }
            f = fdLL.getNext();
        }
        System.out.println("-----------------------------------------------------------------------------------------------");
        return temp;
        
    }
    
    private static void insertNewFood(LinkedList fdLL)
    {
        String id,name,exp,vid,status;
        int qty;
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter New Food ID:");
        id=in.nextLine();
        System.out.println("Enter New Food Name:");
        name=in.nextLine();
        System.out.println("Enter New Food Quantity:");
        qty=in.nextInt();
        in.nextLine();
        System.out.println("Enter New Food Expiry Date:");
        exp=in.nextLine();
        System.out.println("Enter New Food Victim ID:");
        vid=in.nextLine();
        System.out.println("Enter New Food Status:");
        status=in.nextLine();
        
        FoodDonation f = new FoodDonation(id,name,qty,exp,vid,status);
        fdLL.addLast(f);
    }
    
    private static void distributingOperation(LinkedList<FoodDonation> ll , Queue<Victim> q)
    {
        FoodDonation f = ll.getFirst();
        Victim v = q.dequeue();
        Scanner in = new Scanner(System.in);
        Queue<Victim> temp = new Queue();
        int c ;
       
        
        System.out.printf("%-10s | %-32s | %5s | %-15s | %-12s | %-12s%n","FOOD ID", "FOOD NAME", "QTY", "EXPIRY DATE", "VICTIM ID", "STATUS");
        System.out.println("-----------------------------------------------------------------------------------------------");
        while(f!=null)
        {
            if(f.getStatus().equalsIgnoreCase("Approved")&&f.getStatus().equalsIgnoreCase("Pending"))
            {   System.out.printf("%-10s | %-32s | %5d | %-15s | %-12s | %-12s%n",
                f.getFoodID(), f.getFoodName(), f.getFoodQty(),
                f.getFoodExpDate(), f.getVictimID(), f.getStatus());
            }
            f = ll.getNext();
            
        }
        System.out.println("-----------------------------------------------------------------------------------------------");
        
        System.out.print("1. Start Distributing Operation || 2. Exit");
        c = in.nextInt();
        switch (c)
        {
            case 1 : while(f!=null)
                    {
                        System.out.println("Enter ");
                    }
        }
    }
}      

