# Food Donation Bank Operation System

Java console-based food donation and hunger relief system for a data structures academic group project.

## Included source files
- MainRemake.java
- FoodDonation.java
- Victim.java
- LinkedList.java
- Queue.java
- Node.java

## Note
Sample data files from the original assignment are not included in this public-friendly source package.
