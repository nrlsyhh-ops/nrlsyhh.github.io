public class Victim
{
    private String victimID;
    private String victimName;
    private String victimPhoneNum;
    private String victimAddress;
    private int familySize;
    
    public Victim(String a,String b,String c,String d,int e)
    {
        this.victimID = a;
        this.victimName = b;
        this.victimPhoneNum = c;
        this.victimAddress = d;
        this.familySize = e;
    }
    
    public String getVictimID(){return this.victimID;}
    public String getName(){return this.victimName;}
    public String getPhone(){return this.victimPhoneNum;}
    public String getAddress(){return this.victimAddress;}
    public int getFamSize(){return this.familySize;}
    
    public String toString(){return String.format("\nVictim ID : %s \nVictim Name : %s \nVictim Phone No: %s \nVictim Address : %s \nFamily Size : %d",victimID,victimName,victimPhoneNum,victimAddress,familySize);}
}
